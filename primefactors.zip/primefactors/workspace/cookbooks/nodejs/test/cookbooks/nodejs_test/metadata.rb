name 'nodejs_test'
version '0.1.0'

depends 'git'
